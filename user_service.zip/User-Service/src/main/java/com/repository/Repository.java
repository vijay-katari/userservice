package com.repository;


import com.user.model.User;

public interface Repository extends JpaRepository<User, Long> {
}

