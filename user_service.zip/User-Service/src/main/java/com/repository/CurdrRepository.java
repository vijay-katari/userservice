package com.repository;



import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.user.model.Contact;

public interface CurdrRepository extends CrudRepository<Contact, Long> {
    List<Contact> findByUserId(Long userId); // Custom finder method
}

