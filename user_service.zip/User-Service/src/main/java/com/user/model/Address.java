package com.user.model;


public class Address {
	private Long userId;
	private String houseNumber;
	private String place;
	
	public Address(Long userId, String houseNumber, String place) {
		super();
		this.userId = userId;
		this.houseNumber = houseNumber;
		this.place = place;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	
	
	
}

