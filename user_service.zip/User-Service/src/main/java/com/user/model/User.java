package com.user.model;

import java.util.ArrayList;
import java.util.List;

public class User {
	private Long userId;
	private String name;
	private String phone;
	
	List<Contact> contact = new ArrayList<>();
	
	List<Address> address = new ArrayList<>();
	
	

	public User(Long userId, String name, String phone) {
		super();
		this.userId = userId;
		this.name = name;
		this.phone = phone;
	}



	public User(Long userId, String name, String phone, List<Contact> contact,List<Address> address) {
		super();
		this.userId = userId;
		this.name = name;
		this.phone = phone;
		this.contact = contact;
		this.address= address;
	}



	public List<Address> getAddress() {
		return address;
	}



	public void setAddress(List<Address> address) {
		this.address = address;
	}



	public Long getUserId() {
		return userId;
	}



	public void setUserId(Long userId) {
		this.userId = userId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getPhone() {
		return phone;
	}



	public void setPhone(String phone) {
		this.phone = phone;
	}



	public List<Contact> getContact() {
		return contact;
	}



	public void setContact(List<Contact> contact) {
		this.contact = contact;
	}
	
	
	

}
