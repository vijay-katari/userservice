package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.model.Address;
import com.user.model.Contact;
import com.user.model.User;
import com.user.service.AddressService;
import com.user.service.ContactService;
import com.user.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@Autowired 
	private ContactService contactService;
	
	@Autowired
	private AddressService addressService;
	
	@GetMapping("/{userId}")
	public User getUser(@PathVariable Long userId)
	   {
		 User user = this.userService.getUser(userId);
		 if (user != null) {
	            List<Contact> contacts = contactService.getContactsOfUser(userId);
	            List<Address> address = addressService.getAddressOfUser(userId);
	            user.setContact(contacts);
	            user.setAddress(address);
	        }
		return user ;
		
	}
	
}
