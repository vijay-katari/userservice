package com.user.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.user.model.Address;

@Service
public class AddressServiceImpl implements AddressService  {
	
	List<Address> list = Arrays.asList(
            new Address(101L,"8-12","hyd"),
            new Address(102L,"8-13","hyd"),
            new Address(103L,"8-13","hyd"),
            new Address(104L,"8-13","hyd")
    );


    @Override
    public List<Address> getAddressOfUser(Long userId) {
        return list.stream()
        		.filter(address -> address.getUserId()
        				.equals(userId)).collect(Collectors.toList());
    }

}
