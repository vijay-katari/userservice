package com.user.service;

import com.user.model.User;

public interface UserService {

	public User getUser(Long id);
}
